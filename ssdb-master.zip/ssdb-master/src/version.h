#ifndef SSDB_DEPS_H
#ifndef SSDB_VERSION
#define SSDB_VERSION "1.6.8.6"
#include <stdlib.h>
#include <jemalloc/jemalloc.h>
#endif
#endif
