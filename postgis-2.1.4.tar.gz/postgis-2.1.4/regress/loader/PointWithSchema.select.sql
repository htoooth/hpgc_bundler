select ST_Asewkt(the_geom) from pgreg.loadedshp order by 1;

