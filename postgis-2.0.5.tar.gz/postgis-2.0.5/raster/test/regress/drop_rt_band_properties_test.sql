DROP TABLE rt_band_properties_test;
