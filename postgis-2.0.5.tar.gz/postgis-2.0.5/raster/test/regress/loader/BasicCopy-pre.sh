cp loader/testraster.tif loader/BasicCopy.tif
